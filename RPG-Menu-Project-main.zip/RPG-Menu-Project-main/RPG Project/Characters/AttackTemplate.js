//template class for attacks
class AttackTemplate{
    
    constructor ()
    {
        this.attackName;
        this.description;
        this.power;
        this.accuracy;
        this.stamina;
        this.currentStamina;
        this.effect;
        this.effectValue;
    }
}

export {AttackTemplate};