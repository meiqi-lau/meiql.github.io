//template class for characters
class CharacterTemplate{

    constructor (name)
    {
        this.name = name;
        this.maxHealth;
        this.currentHealth;
        //array of moves
        this.moveset = [];
    }
}

export {CharacterTemplate};