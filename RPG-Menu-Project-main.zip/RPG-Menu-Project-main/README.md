RPG Menu Project

goal: use phaser and implement a rpg narrative game, with a turn based battle mechanic (RPG action menu)


(if you uploaded a renamed file, can you try to delete the previous file in git)


Start：You will need Node.js to build the game.


